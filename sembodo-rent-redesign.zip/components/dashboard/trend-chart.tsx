"use client"

import { Area, AreaChart, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts"

const trendData = [
  { month: "Jan", total: 186 },
  { month: "Feb", total: 305 },
  { month: "Mar", total: 237 },
  { month: "Apr", total: 273 },
  { month: "Mei", total: 409 },
  { month: "Jun", total: 314 },
  { month: "Jul", total: 356 },
  { month: "Agu", total: 428 },
  { month: "Sep", total: 389 },
  { month: "Okt", total: 467 },
  { month: "Nov", total: 512 },
  { month: "Des", total: 589 },
]

export function TrendChart() {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border p-5">
        <h3 className="text-base font-semibold text-foreground">Tren Penyewaan Bulanan</h3>
        <p className="mt-1 text-xs text-muted-foreground">Total transaksi penyewaan per bulan</p>
      </div>
      <div className="p-5">
        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={trendData}>
            <defs>
              <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis
              dataKey="month"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
            />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                color: "hsl(var(--popover-foreground))",
              }}
              labelStyle={{ color: "hsl(var(--popover-foreground))" }}
            />
            <Area
              type="monotone"
              dataKey="total"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2}
              fill="url(#colorTotal)"
              dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 0, r: 4 }}
              activeDot={{ r: 6, fill: "hsl(var(--chart-1))" }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
