import { Database, ArrowRight } from "lucide-react"
import Link from "next/link"

interface EmptyStateProps {
  type: "no-data" | "not-analyzed"
}

export function EmptyState({ type }: EmptyStateProps) {
  if (type === "no-data") {
    return (
      <div className="rounded-xl border border-border bg-gradient-to-br from-card to-secondary/30 p-8">
        <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto py-8">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 mb-6">
            <Database className="h-8 w-8 text-primary" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">Data Transaksi Belum Tersedia</h3>
          <p className="text-sm text-muted-foreground mb-6">
            Sistem belum bisa menampilkan analisis performa armada, tren penyewaan bulanan, dan proporsi layanan karena
            belum ada data yang masuk.
          </p>
          <Link
            href="/upload"
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Impor Data Sekarang
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="rounded-xl border border-border bg-gradient-to-br from-card to-accent/10 p-8">
      <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto py-8">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-accent/20 mb-6">
          <svg className="h-8 w-8 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
            />
          </svg>
        </div>
        <h3 className="text-xl font-semibold text-foreground mb-2">Data Siap Dianalisis</h3>
        <p className="text-sm text-muted-foreground mb-6">
          Data transaksi telah diunggah, namun sistem belum melakukan analisis K-Means. Silakan jalankan proses analisis
          untuk melihat Dashboard Performa Armada.
        </p>
        <Link
          href="/kmeans"
          className="inline-flex items-center gap-2 rounded-lg bg-accent px-5 py-2.5 text-sm font-medium text-accent-foreground transition-colors hover:bg-accent/90"
        >
          Jalankan Analisis K-Means
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  )
}
