"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { Key, User } from "lucide-react"

const proportionData = [
  { name: "Lepas Kunci", value: 65 },
  { name: "Dengan Driver", value: 35 },
]

const topLepasKunci = [
  { name: "Toyota Alphard", points: 145 },
  { name: "Mitsubishi Xpander", points: 128 },
  { name: "Toyota Innova", points: 112 },
  { name: "Toyota Fortuner", points: 98 },
  { name: "Toyota Avanza", points: 85 },
]

const topDriver = [
  { name: "Toyota Alphard", points: 165 },
  { name: "Toyota HiAce", points: 142 },
  { name: "Bus Pariwisata", points: 128 },
  { name: "Toyota Innova", points: 95 },
  { name: "Mercedes Benz", points: 78 },
]

const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))"]

export function ServiceProportion() {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border p-5">
        <h3 className="text-base font-semibold text-foreground">Proporsi Layanan</h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Poin dihitung berdasarkan jumlah transaksi dan total unit yang disewa
        </p>
      </div>
      <div className="p-5">
        {/* Donut Chart */}
        <div className="flex items-center justify-center gap-8 mb-6">
          <div className="h-44 w-44">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={proportionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {proportionData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    color: "hsl(var(--popover-foreground))",
                  }}
                  formatter={(value: number) => [`${value}%`, ""]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="h-3 w-8 rounded bg-chart-1" />
              <span className="text-sm font-medium text-foreground">Lepas Kunci</span>
              <span className="text-sm text-muted-foreground">65%</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-3 w-8 rounded bg-chart-2" />
              <span className="text-sm font-medium text-foreground">Dengan Driver</span>
              <span className="text-sm text-muted-foreground">35%</span>
            </div>
          </div>
        </div>

        {/* Top Lists */}
        <div className="border-t border-border pt-5">
          <div className="grid grid-cols-2 gap-6">
            {/* Lepas Kunci */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Key className="h-4 w-4 text-chart-1" />
                <h4 className="text-sm font-medium text-foreground">Top 5 Lepas Kunci</h4>
              </div>
              <div className="space-y-2">
                {topLepasKunci.map((item, index) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between rounded-md bg-secondary/50 px-3 py-2"
                  >
                    <span className="text-xs text-foreground">
                      <span className="text-muted-foreground mr-1">{index + 1}.</span>
                      {item.name}
                    </span>
                    <span className="rounded-full bg-chart-1/10 px-2 py-0.5 text-xs font-medium text-chart-1">
                      {item.points} Poin
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Dengan Driver */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <User className="h-4 w-4 text-chart-2" />
                <h4 className="text-sm font-medium text-foreground">Top 5 Dengan Driver</h4>
              </div>
              <div className="space-y-2">
                {topDriver.map((item, index) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between rounded-md bg-secondary/50 px-3 py-2"
                  >
                    <span className="text-xs text-foreground">
                      <span className="text-muted-foreground mr-1">{index + 1}.</span>
                      {item.name}
                    </span>
                    <span className="rounded-full bg-chart-2/10 px-2 py-0.5 text-xs font-medium text-chart-2">
                      {item.points} Poin
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
