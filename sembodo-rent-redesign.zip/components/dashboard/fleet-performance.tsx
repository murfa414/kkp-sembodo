"use client"

import { cn } from "@/lib/utils"
import Image from "next/image"

interface FleetItem {
  id: number
  name: string
  transactions: number
  units: number
  score: number
  image: string
}

const fleetData: FleetItem[] = [
  { id: 1, name: "Toyota Alphard", transactions: 245, units: 890, score: 95, image: "/toyota-alphard-luxury-van-white.jpg" },
  { id: 2, name: "Toyota Innova Zenix", transactions: 198, units: 720, score: 88, image: "/toyota-innova-zenix-suv-white.jpg" },
  { id: 3, name: "Mitsubishi Xpander", transactions: 175, units: 650, score: 82, image: "/mitsubishi-xpander-mpv-white.jpg" },
  { id: 4, name: "Toyota Fortuner VRZ", transactions: 120, units: 480, score: 65, image: "/toyota-fortuner-suv-white.jpg" },
  { id: 5, name: "Toyota Avanza", transactions: 95, units: 380, score: 52, image: "/toyota-avanza-mpv-white.jpg" },
  { id: 6, name: "Mitsubishi Pajero", transactions: 78, units: 290, score: 42, image: "/mitsubishi-pajero-sport-suv-white.jpg" },
  { id: 7, name: "Toyota HiAce", transactions: 65, units: 240, score: 35, image: "/toyota-hiace-van-white.jpg" },
  {
    id: 8,
    name: "Mercedes Benz E-Class",
    transactions: 45,
    units: 150,
    score: 25,
    image: "/mercedes-benz-e-class-sedan-white.jpg",
  },
]

function getStatusBadge(index: number) {
  if (index < 3) return { label: "Laris", color: "bg-chart-1 text-white" }
  if (index < 6) return { label: "Sedang", color: "bg-chart-3 text-background" }
  return { label: "Kurang Laris", color: "bg-destructive text-white" }
}

export function FleetPerformance() {
  const maxScore = Math.max(...fleetData.map((f) => f.score))

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border p-5">
        <h3 className="text-base font-semibold text-foreground">Performa Armada</h3>
        <p className="mt-1 text-xs text-muted-foreground">Berdasarkan rata-rata frekuensi sewa dan total unit</p>
      </div>
      <div className="max-h-[520px] overflow-y-auto p-4">
        <div className="space-y-3">
          {fleetData.map((item, index) => {
            const status = getStatusBadge(index)
            const percentage = (item.score / maxScore) * 100
            const progressColor = index < 3 ? "bg-chart-1" : index < 6 ? "bg-chart-3" : "bg-destructive"

            return (
              <div key={item.id} className="group rounded-lg bg-secondary/50 p-3 transition-all hover:bg-secondary">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">
                    <span className="text-muted-foreground mr-2">{index + 1}.</span>
                    {item.name}
                  </span>
                  <span className={cn("rounded-full px-2.5 py-0.5 text-xs font-medium", status.color)}>
                    {status.label}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative h-12 w-24 flex-shrink-0">
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      fill
                      className="object-contain drop-shadow-lg"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
                      <span>
                        {item.transactions} Transaksi • {item.units} Unit
                      </span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                      <div
                        className={cn("h-full rounded-full transition-all duration-500", progressColor)}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
