"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { StatCard } from "@/components/dashboard/stat-card"
import { FleetPerformance } from "@/components/dashboard/fleet-performance"
import { TrendChart } from "@/components/dashboard/trend-chart"
import { ServiceProportion } from "@/components/dashboard/service-proportion"
import { EmptyState } from "@/components/dashboard/empty-state"
import { Car, TrendingUp, Users, Calendar } from "lucide-react"

// Simulasi state untuk demo
type DashboardState = "has-data" | "no-data" | "not-analyzed"

export default function DashboardPage() {
  const [dashboardState] = useState<DashboardState>("has-data")

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64">
        <Header title="SEMBODO RENT A CAR" />

        <div className="p-6">
          {dashboardState === "no-data" && <EmptyState type="no-data" />}
          {dashboardState === "not-analyzed" && <EmptyState type="not-analyzed" />}

          {dashboardState === "has-data" && (
            <div className="space-y-6">
              {/* Stats Grid */}
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <StatCard
                  title="Total Armada"
                  value="127"
                  subtitle="Unit aktif"
                  icon={Car}
                  trend={{ value: 12, isPositive: true }}
                />
                <StatCard
                  title="Total Transaksi"
                  value="4,658"
                  subtitle="Tahun ini"
                  icon={TrendingUp}
                  trend={{ value: 8, isPositive: true }}
                />
                <StatCard
                  title="Pelanggan Aktif"
                  value="892"
                  subtitle="Bulan ini"
                  icon={Users}
                  trend={{ value: 5, isPositive: true }}
                />
                <StatCard title="Rata-rata Durasi" value="3.2" subtitle="Hari per sewa" icon={Calendar} />
              </div>

              {/* Main Content Grid */}
              <div className="grid gap-6 lg:grid-cols-5">
                {/* Fleet Performance - 2 columns */}
                <div className="lg:col-span-2">
                  <FleetPerformance />
                </div>

                {/* Charts - 3 columns */}
                <div className="lg:col-span-3 space-y-6">
                  <TrendChart />
                  <ServiceProportion />
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
